import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JButton;

public class MenuPanel extends JPanel {

	JButton newGameButton;
    JButton quitButton;
    JButton giveUpButton;
    JButton undoButton;

	public MenuPanel() {
	    setSize(300, 600);
	    setLayout(new GridLayout(2,2,5,5));

	    
	    newGameButton = new JButton("New Game");
	    add(newGameButton);
	    quitButton = new JButton("Quit");
	    add(quitButton);
	    giveUpButton = new JButton("Give Up");
	    add(giveUpButton);
	    undoButton = new JButton("Undo");
	    add(undoButton);
 
	    setVisible(true);    

	}		
	
}
