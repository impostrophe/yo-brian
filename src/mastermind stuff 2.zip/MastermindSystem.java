public class MastermindSystem {
	
	private boolean isRunning;
	private int turn;
	private int guessPos;
	private enum PegColor {RED, YELLOW, BLUE, PURPLE, ORANGE, GREEN};
	
	public MastermindSystem() {
		isRunning = true;
		turn = 0;
		guessPos = 0;
	}
	
	public boolean getIsRunning() {
		if (turn == 9 && guessPos == 3) {
			isRunning = false;
		}
		return isRunning;
	}
	
	public int getTurn() {
		return turn;
	}
	
	public int getGuessPos() {
		return guessPos;
	}
	
	public void newGame() {
		turn = 0;
		guessPos = 0;
		isRunning = true;
	}
	
	public void gameOver() {
		isRunning = false;
		//show solution
		//want to play again?
	}
	
	public void undoMove() {
		if (guessPos > 0) {
			guessPos--;
		}
	}
	
	public void setBackgroundColor(PegColor color) {
	}

	public void clickButton() {
		if (isRunning) {
			if (guessPos < 3) {
				guessPos++;
			} else {
				checkGuess();
				turn++;
				guessPos = 0;
				
			}
		}

	}
	
	public void checkGuess() {
		//Implement
		//check elements of guess against solution and set background color of clue panels
	}
	
}
