import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
	
public class MastermindGame extends JFrame implements ActionListener {
	
	
	public static void main(String[] args) {		
		MastermindGame gameLaunch = new MastermindGame();
	    }
	
	MastermindSystem gameSystem;
	JPanel guessContainer;
	JPanel[][] guessPanel;
	PegPanel pegPanel;
	CluePanel cluePanel;
	MenuPanel menuPanel;
		
	public MastermindGame() {
		
		gameSystem = new MastermindSystem();
		
	    setSize(600, 800);
	    setLocationRelativeTo(null);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setLayout(new BorderLayout());

	    
	    guessContainer = new JPanel();
	    // create array of JPanels
	    guessPanel = new JPanel[10][4];

	    // loop through JPanel array to initialize JPanels
	    for (int a = 0; a < guessPanel.length; a++) {
	        for (int b = 0; b < guessPanel[0].length; b++) {
	        	guessPanel[a][b] = new JPanel();
	        	guessContainer.add(guessPanel[a][b]);
	        }
	    }
	    


		add(guessContainer, BorderLayout.WEST);
	    pegPanel = new PegPanel();
	    add(pegPanel, BorderLayout.SOUTH);
	    cluePanel = new CluePanel();
	    add(cluePanel, BorderLayout.EAST);
	    menuPanel = new MenuPanel();
	    add(menuPanel, BorderLayout.NORTH);
	
	    
	    defaultGuessPanelColors();
	    setVisible(true);

	    //add action listener to menu buttons
	    menuPanel.newGameButton.addActionListener(this);
	    menuPanel.quitButton.addActionListener(this);
	    menuPanel.giveUpButton.addActionListener(this);
	    menuPanel.undoButton.addActionListener(this);

	    //add action listener to color buttons	    
	    pegPanel.redButton.addActionListener(this);
	    pegPanel.yellowButton.addActionListener(this);
	    pegPanel.blueButton.addActionListener(this);
	    pegPanel.greenButton.addActionListener(this);
	    pegPanel.orangeButton.addActionListener(this);
	    pegPanel.purpleButton.addActionListener(this);

	} // end of MastermindGame constructor

    public void defaultGuessPanelColors() {
    for (int i = 0; i < guessPanel.length; i++) {
    	for (int j = 0; j < guessPanel[i].length; j++) {
    		guessPanel[i][j].setBackground(Color.GRAY);
    	}
    }
}	
	
	// handle button clicks
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == menuPanel.newGameButton) {
		    for (int i = 0; i < guessPanel.length; i++) {
		    	for (int j = 0; j < guessPanel[i].length; j++) {
		    		guessPanel[i][j].setBackground(Color.GRAY);
		    	}
		    }
		    defaultGuessPanelColors();		    
			gameSystem.newGame();
		} else if (event.getSource() == menuPanel.quitButton) {
			System.exit(0);
		} else if (gameSystem.getIsRunning() == true) {

			if (event.getSource() == menuPanel.giveUpButton) {
				gameSystem.gameOver();			
			} else if (event.getSource() == menuPanel.undoButton) {
				gameSystem.undoMove();
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.gray);
			} else if (event.getSource() == pegPanel.redButton) {
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.red);
				gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.yellowButton) {
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.yellow);
				gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.blueButton) {			
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.blue);
				gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.greenButton) {
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.green);
				gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.orangeButton) {
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.orange);
				gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.purpleButton) {			
				guessPanel[gameSystem.getTurn()][gameSystem.getGuessPos()].setBackground(Color.magenta);
				gameSystem.clickButton();
			}

		}
	}
	
} // end of MastermindGame class