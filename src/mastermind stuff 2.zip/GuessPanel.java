import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class GuessPanel extends JPanel {

	JPanel[][] guessPanel;
	JPanel guessPanelContainer;
	
	public GuessPanel() {
	    setSize(300, 600);
	    setLayout(new GridLayout(10,4,5,5));

	    guessPanel = new JPanel[10][4];
	    guessPanelContainer = new JPanel();
	    
	    for (int a = 0; a < guessPanel.length; a++) {
	        for (int b = 0; b < guessPanel[0].length; b++) {
	        	guessPanel[a][b] = new JPanel();
	        	guessPanelContainer.add(guessPanel[a][b]);
	        }
	    }
	    
	    for (int i = 0; i < guessPanel.length; i++) {
	    	for (int j = 0; j < guessPanel[i].length; j++) {
	    		guessPanel[i][j].setBackground(Color.GRAY);
	    	}
	    }
	    
	    setVisible(true);
	}
			
}
