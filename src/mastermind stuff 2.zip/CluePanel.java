import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class CluePanel extends JPanel{

	JPanel[][] cluePanel;
	JPanel cluePanelContainer;
	
	public CluePanel() {
	    setSize(300, 600);
	    setLayout(new GridLayout(10,4,5,5));

	    cluePanel = new JPanel[10][4];
	    cluePanelContainer = new JPanel();

	    for (int a = 0; a < cluePanel.length; a++) {
	        for (int b = 0; b < cluePanel[0].length; b++) {
	        	cluePanel[a][b] = new JPanel();
	        	cluePanelContainer.add(cluePanel[a][b]);
	        }
	    }
	    
	    for (int i = 0; i < cluePanel.length; i++) {
	    	for (int j = 0; j < cluePanel[i].length; j++) {
	    		cluePanel[i][j].setBackground(Color.GRAY);
	    	}
	    }

	    setVisible(true);
	}	

}
