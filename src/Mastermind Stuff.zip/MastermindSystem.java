public class MastermindSystem {

	public static void main(String[] args) {
		
		MastermindSystem mastermind = new MastermindSystem();
						
	}
	
	private boolean isRunning;
	private int turn;
	private int guessPos;
	private enum PegColor {RED, YELLOW, BLUE, PURPLE, ORANGE, GREEN};
	MastermindGame newBoard;
	
	public MastermindSystem() {
		isRunning = false;
		turn = 0;
		guessPos = 0;
		newBoard = new MastermindGame();
	}
	
	public int getTurn() {
		return this.turn;
	}
	
	public int getGuessPos() {
		return this.guessPos;
	}
	
	public void newGame() {
		this.turn = 0;
		this.guessPos = 0;
	}
	
	public void gameOver() {
		//show solution
		//want to play again?
	}
	
	public void setBackgroundColor(PegColor color) {
	}

	public void clickButton() {
		if (isRunning) {
			//set background color
			if (guessPos < 4) {
				guessPos++;
			} else {
				checkGuess();
				turn++;
				guessPos = 0;
				
			}
			this.guessPos++;
		}

	}
	
	public void checkGuess() {
		//Implement
		//check elements of guess against solution and set background color of clue panels
	}
	
}
