import java.awt.FlowLayout;
import javax.swing.JFrame;
	
public class MastermindGame extends JFrame {
	
	public static void main(String[] args) {
		
		MastermindSystem launch = new MastermindSystem();
		
	}
	
	public MastermindGame() {
	    setSize(600, 800);
	    setLocationRelativeTo(null);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setLayout(new FlowLayout());

	    GuessPanel guessPanel = new GuessPanel();
	    add(guessPanel);
	    PegPanel pegPanel = new PegPanel();
	    add(pegPanel);
	    CluePanel cluePanel = new CluePanel();
	    add(cluePanel);
	    MenuPanel menuPanel = new MenuPanel();
	    add(menuPanel);

	    setVisible(true);
	}	
	
}