import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PegPanel extends JPanel{

	public PegPanel() {
	    setSize(300, 600);
	    setLayout(new GridLayout(2,3,15,15));

	    JButton redButton;
	    JButton yellowButton;
	    JButton blueButton;
	    JButton greenButton;
	    JButton purpleButton;
	    JButton orangeButton;
	    
	    redButton = new JButton("Red");
	    add(redButton);
	    redButton.setBackground(Color.red);
	    yellowButton = new JButton("Yellow");
	    add(yellowButton);
	    yellowButton.setBackground(Color.yellow);
	    blueButton = new JButton("Blue");
	    add(blueButton);
	    blueButton.setBackground(Color.blue);
	    greenButton = new JButton("Green");
	    add(greenButton);
	    greenButton.setBackground(Color.green);
	    purpleButton = new JButton("Purple");
	    add(purpleButton);
	    purpleButton.setBackground(Color.magenta);
	    orangeButton = new JButton("Orange");
	    add(orangeButton);
	    orangeButton.setBackground(Color.orange);

	    setVisible(true);
	}	

}
