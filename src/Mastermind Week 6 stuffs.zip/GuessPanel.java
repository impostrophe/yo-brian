import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class GuessPanel extends JPanel {

	JPanel[][] guessPanelArray;
	
	public GuessPanel() {
	    setSize(300,600);
	    setLayout(new GridLayout(10,4,5,5));

	    guessPanelArray = new JPanel[10][4];
	    
	    for (int a = 0; a < guessPanelArray.length; a++) {
	        for (int b = 0; b < guessPanelArray[0].length; b++) {
	        	guessPanelArray[a][b] = new JPanel();
	        	add(guessPanelArray[a][b]);
	        }
	    }
	    
	    setDefaultColors();
	    
	    setVisible(true);
	}
	
	public void setDefaultColors() {
	    for (int i = 0; i < guessPanelArray.length; i++) {
	    	for (int j = 0; j < guessPanelArray[i].length; j++) {
	    		guessPanelArray[i][j].setBackground(Color.GRAY);
	    	}
	    }
	}
	
	public JPanel getPanel(int x, int y) {
		return guessPanelArray[x][y];
	}

	public Color getColor(int x, int y) {
		return guessPanelArray[x][y].getBackground();
	}

}
