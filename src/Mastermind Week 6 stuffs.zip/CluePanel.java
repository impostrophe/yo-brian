import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class CluePanel extends JPanel{

	JPanel[][] cluePanel;
	
	public CluePanel() {
	    setSize(300, 600);
	    setLayout(new GridLayout(10,4,5,5));

	    cluePanel = new JPanel[10][4];

	    for (int a = 0; a < cluePanel.length; a++) {
	        for (int b = 0; b < cluePanel[0].length; b++) {
	        	cluePanel[a][b] = new JPanel();
	        	add(cluePanel[a][b]);
	        }
	    }
	    
	    setDefaultColors();

	    setVisible(true);
	}	

	public void setDefaultColors() {
	    for (int i = 0; i < cluePanel.length; i++) {
	    	for (int j = 0; j < cluePanel[i].length; j++) {
	    		cluePanel[i][j].setBackground(Color.GRAY);
	    	}
	    }
    }
	
	public JPanel getPanel(int x, int y) {
		return cluePanel[x][y];
	}

	public Color getColor(int x, int y) {
		return cluePanel[x][y].getBackground();
	}
	
	public void setSolutionArray() {
	    for (int i = 0; i < cluePanel.length; i++) {
	    	for (int j = 0; j < cluePanel[i].length; j++) {
	    		cluePanel[i][j].setBackground(Color.GRAY);		
	    	}
	    }	
	}
	
}
