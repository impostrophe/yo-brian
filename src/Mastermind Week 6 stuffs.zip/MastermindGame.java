import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
	
public class MastermindGame extends JFrame implements ActionListener {
	
	public static void main(String[] args) {		
		MastermindGame gameLaunch = new MastermindGame();	
	}
	
	MastermindSystem gameSystem;
	GuessPanel guessPanel;
	PegPanel pegPanel;
	CluePanel cluePanel;
	MenuPanel menuPanel;
	SolutionPanel solution;
	int correct;
		
	public MastermindGame() {
		
		gameSystem = new MastermindSystem();
		correct = 0;
		
	    setSize(600, 800);
	    setLocationRelativeTo(null);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setLayout(new BorderLayout());

	    
	    guessPanel = new GuessPanel();
	    add(guessPanel, BorderLayout.WEST);
	    pegPanel = new PegPanel();
	    add(pegPanel, BorderLayout.SOUTH);
	    cluePanel = new CluePanel();
	    add(cluePanel, BorderLayout.EAST);
	    menuPanel = new MenuPanel();
	    add(menuPanel, BorderLayout.NORTH);
	    solution = new SolutionPanel();
	    add(solution, BorderLayout.CENTER);
	
	    
	    guessPanel.setDefaultColors();
	    setVisible(true);

	    //add action listener to menu buttons
	    menuPanel.newGameButton.addActionListener(this);
	    menuPanel.quitButton.addActionListener(this);
	    menuPanel.giveUpButton.addActionListener(this);
	    menuPanel.undoButton.addActionListener(this);

	    //add action listener to color buttons	    
	    pegPanel.redButton.addActionListener(this);
	    pegPanel.yellowButton.addActionListener(this);
	    pegPanel.blueButton.addActionListener(this);
	    pegPanel.greenButton.addActionListener(this);
	    pegPanel.orangeButton.addActionListener(this);
	    pegPanel.purpleButton.addActionListener(this);

	} // end of MastermindGame constructor
		
	// handle button clicks
	public void actionPerformed(ActionEvent event) {
		if (guessPanel.getPanel(0, 0).getBackground() == solution.getPanel(0).getBackground()) {
			System.out.println("hi");
		} else {
			System.out.println("no");
		}
		if (event.getSource() == menuPanel.newGameButton) {
		    guessPanel.setDefaultColors();
		    cluePanel.setDefaultColors();
		    solution.setDefaultColors();
		    solution.setSolutionArray();
			gameSystem.newGame();
		} else if (event.getSource() == menuPanel.quitButton) {
			System.exit(0);
		} else if (gameSystem.getIsRunning() == true) {

			if (event.getSource() == menuPanel.giveUpButton) {
				gameSystem.gameOver();			
				solution.showSolution();
			} else if (event.getSource() == menuPanel.undoButton) {
				gameSystem.undoMove();
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.gray);
				return;
			} else if (event.getSource() == pegPanel.redButton) {
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.red);
				//gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.yellowButton) {
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.yellow);
				//gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.blueButton) {			
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.blue);
				//gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.greenButton) {
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.green);
				//gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.orangeButton) {
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.orange);
				//gameSystem.clickButton();
			} else if (event.getSource() == pegPanel.purpleButton) {			
				guessPanel.getPanel(gameSystem.getTurn(), gameSystem.getGuessPos()).setBackground(Color.magenta);
				//gameSystem.clickButton();
			}
			if (gameSystem.getGuessPos() == 3) {
				correct = 0;
				for (int i = 0; i < 4; i++) {
					for (int j = 0; j < 4; j++) {
						if (guessPanel.getPanel(i, j).getBackground() == solution.getPanel(j).getBackground()) {
							if (i == j) {
								cluePanel.getPanel(i, j).setBackground(Color.WHITE);
								correct++;
							} else {
								cluePanel.getPanel(i, j).setBackground(Color.RED);
							}
						}
					}
					if (correct == 4) {
						gameSystem.gameOver();
						solution.showSolution();
					}
				}
			}
			gameSystem.clickButton();
		}
	}
	
	
} // end of MastermindGame class