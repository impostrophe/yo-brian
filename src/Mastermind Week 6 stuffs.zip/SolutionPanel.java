import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Random;

public class SolutionPanel extends JPanel {

	JPanel[] solutionArray;
	JPanel[] solutionHiddenArray;
	int randomNum;
	Random rand = new Random();
	
	public SolutionPanel() {
	    setSize(300,600);
	    setLayout(new GridLayout(1,4,5,5));

	    solutionArray = new JPanel[4];
	    solutionHiddenArray = new JPanel[4];
	    
	    for (int a = 0; a < solutionArray.length; a++) {
	    	solutionArray[a] = new JPanel();
	        }
	    
	    for (int a = 0; a < solutionHiddenArray.length; a++) {
	    	solutionHiddenArray[a] = new JPanel();
	        add(solutionHiddenArray[a]);
	        }	    
	    
	    setDefaultColors();
	    setSolutionArray();
	    
	    setVisible(true);
	}
	
	public void setDefaultColors() {
	    for (int i = 0; i < solutionHiddenArray.length; i++) {
	    	solutionHiddenArray[i].setBackground(Color.GRAY);
	    }
    }
	
	public JPanel getPanel(int x) {
		return solutionArray[x];
	}
	
	public void setSolutionArray() {
	    for (int i = 0; i < solutionArray.length; i++) {
	    	randomNum = ThreadLocalRandom.current().nextInt(0, 6);
	    	//randomNum = rand.nextInt(6);
	    	
	    	switch (randomNum) {
	    		case 0:
	    				solutionArray[i].setBackground(Color.RED);
	    				break;
	    		case 1:
	    				solutionArray[i].setBackground(Color.YELLOW);		
	    				break;
	    		case 2:
	    				solutionArray[i].setBackground(Color.BLUE);		
	    				break;
	    		case 3:
	    				solutionArray[i].setBackground(Color.GREEN);		
	    				break;
	    		case 4:
	    				solutionArray[i].setBackground(Color.ORANGE);		
	    				break;
	    		case 5:
	    				solutionArray[i].setBackground(Color.MAGENTA);		
	    				break;
	    	
	    	}
	    }	
	}
	
	public void showSolution() {
		for (int i = 0; i < 4; i++) {
		solutionHiddenArray[i].setBackground(solutionArray[i].getBackground());
		}
	}
	
} // end of Solution class
